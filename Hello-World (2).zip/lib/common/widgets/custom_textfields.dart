import 'package:flutter/material.dart';

class CustomTextField extends StatelessWidget {
  final TextEditingController controller;
  final String hintText;
  final bool obscureText; // خاصية لتشفير كلمة المرور
  final String? Function(String?)? validator; // دالة التحقق من صحة الإدخال

  const CustomTextField({
    Key? key,
    required this.controller,
    required this.hintText,
    this.obscureText = false, // القيمة الافتراضية false
    this.validator,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: controller,
        obscureText: obscureText,
        decoration: InputDecoration(
          hintText: hintText,
          border: const OutlineInputBorder(
            borderSide: BorderSide(color: Colors.black),
          ),
        ),
        validator: validator, // استخدام دالة التحقق من صحة الإدخال
      ),
    );
  }
}
