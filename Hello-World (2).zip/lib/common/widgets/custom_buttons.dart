import 'package:flutter/material.dart';

class MyCustmoBotton extends StatelessWidget {
  final String txt;
  final VoidCallback onClick;
  const MyCustmoBotton({Key? key, required this.txt, required this.onClick})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onClick,
      // ignore: sort_child_properties_last
      child: const Text(' txt '),
      style: ElevatedButton.styleFrom(
        minimumSize: const Size(double.infinity, 50),
      ),
    );
  }
}
