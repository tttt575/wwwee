import 'package:flutter/material.dart';

class Globalvar {
  static const appBarcolor = LinearGradient(
    colors: [
      Color.fromARGB(255, 29, 201, 216),
      Color.fromARGB(255, 29, 201, 216),
    ],
    stops: [0.5, 1.0],
  );

  static const secondaryColor = Color(0xff040701);
  static const backgroundColor = Color(0xffc790e7);
  static const Color greyBackgroundCOlor = Color(0xffebecee);
  static var selectedNavBarColor = Colors.cyan[600];
  static const unselectedNarColor = Colors.black87;
}
